import os
import sys
import threading
import requests
from curl_cffi import requests as curl_requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

THREAD_COUNT = 10

LAZY_ATTRS = [
    "src", "data-src", "data-lazy-src", "data-original",
    "data-img", "data-url", "data-image", "data-lazy",
    "data-hi-res", "data-srcset", "srcset",
]

print_lock = threading.Lock()


def get_page_html(url: str) -> str:
    print("Sayfa yükleniyor...")
    session = curl_requests.Session(impersonate="chrome120")
    response = session.get(url, timeout=30)
    response.raise_for_status()
    return response.text


def download_single(task: dict) -> dict:
    i = task["i"]
    total = task["total"]
    img_url = task["img_url"]
    filepath = task["filepath"]
    filename = task["filename"]

    try:
        session = curl_requests.Session(impersonate="chrome120")
        response = session.get(img_url, timeout=15)
        response.raise_for_status()

        content_type = response.headers.get("Content-Type", "")
        if "image" not in content_type:
            with print_lock:
                print(f"  [{i}/{total}] - {filename}  (gorsel degil, atlandi)")
            return {"success": False}

        with open(filepath, "wb") as f:
            f.write(response.content)

        size_kb = len(response.content) / 1024
        with print_lock:
            print(f"  [{i}/{total}] v {filename}  ({size_kb:.1f} KB)")
        return {"success": True}

    except Exception as e:
        with print_lock:
            print(f"  [{i}/{total}] x {filename}  - {e}")
        return {"success": False}


def download_images(url: str, output_dir: str = "downloaded_images") -> None:
    try:
        html = get_page_html(url)
    except Exception as e:
        print(f"Hata: Sayfa yuklenemedi - {e}")
        sys.exit(1)

    soup = BeautifulSoup(html, "html.parser")
    img_tags = soup.find_all("img")

    if not img_tags:
        print("Sayfada hic gorsel bulunamadi.")
        return

    Path(output_dir).mkdir(parents=True, exist_ok=True)
    print(f"{len(img_tags)} gorsel bulundu. {THREAD_COUNT} paralel baglantiyla indiriliyor...\n")

    tasks = []
    seen_urls = set()
    for i, img in enumerate(img_tags, 1):
        src = None
        for attr in LAZY_ATTRS:
            val = img.get(attr, "").strip()
            if val:
                src = val.split(",")[0].split()[0]
                break
        if not src:
            continue

        img_url = urljoin(url, src)
        if img_url in seen_urls:
            continue
        seen_urls.add(img_url)

        parsed = urlparse(img_url)
        filename = os.path.basename(parsed.path)
        if not filename or "." not in filename:
            filename = f"image_{i}.jpg"

        filepath = Path(output_dir) / filename
        if filepath.exists():
            filepath = Path(output_dir) / f"{filepath.stem}_{i}{filepath.suffix}"

        tasks.append({
            "i": i,
            "total": len(img_tags),
            "img_url": img_url,
            "filepath": filepath,
            "filename": filename,
        })

    success = 0
    with ThreadPoolExecutor(max_workers=THREAD_COUNT) as executor:
        futures = {executor.submit(download_single, task): task for task in tasks}
        for future in as_completed(futures):
            if future.result()["success"]:
                success += 1

    print(f"\nTamamlandi: {success}/{len(tasks)} gorsel indirildi -> '{output_dir}/' klasorune kaydedildi.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Kullanim: python image_downloader.py <URL> [klasor_adi]")
        print("Ornek:    python image_downloader.py https://example.com")
        sys.exit(1)

    target_url = sys.argv[1]
    out_dir = sys.argv[2] if len(sys.argv) > 2 else "downloaded_images"
    download_images(target_url, out_dir)
